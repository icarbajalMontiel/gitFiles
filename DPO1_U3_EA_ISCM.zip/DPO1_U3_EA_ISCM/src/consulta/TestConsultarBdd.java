/**Este programa es el tester del paquete conexion.bdd
 * 
 *  By: Israel Carbajal Montiel
 *  
 *  
 *  **/


package consulta;
import conexion.bdd.conexionMySQL;

public class TestConsultarBdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		conexionMySQL conec=new conexionMySQL();
		System.out.println(conec.establecerConexion());
		System.out.println(conec.insertar());
		System.out.println(conec.cerrarConexion(false));
		

	}

}
