/**Este programa es el tester del paquete empleados
 * 
 *  By: Israel Carbajal Montiel
 *  
 *  
 *  **/
package consulta;

import empleados.Gerentes;
import empleados.Operativos;
import empleados.Temporales;

public class TestDatosEmpleados {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Gerentes g=new Gerentes();
		Operativos o=new Operativos();
		Temporales t=new Temporales();
		g.setDatos("Gerentes");
		o.setDatos("Temporales");
		t.setDatos("Temporales");
		System.out.println(g.getDatosEmpleado());
		System.out.println(o.getDatosEmpleado());
		System.out.println(t.getDatosEmpleado());

	}

}
