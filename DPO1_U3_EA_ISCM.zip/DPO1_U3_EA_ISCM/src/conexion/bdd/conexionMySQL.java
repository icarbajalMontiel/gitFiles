package conexion.bdd;

public class conexionMySQL implements AccesoDatos {

	@Override
	public String establecerConexion() {
		// TODO Auto-generated method stub
		return "Conexi�n establecida con el servidor MySQL";
		
	}

	@Override
	public String insertar() {
		// TODO Auto-generated method stub
		return "Inserta un registro en MySQL";
	}

	@Override
	public String cerrarConexion(boolean statusConexion) {
		
		if(statusConexion==true){
			return "Conexi�n finalizada correctamente";
		}
		else{
			return "Error al cerrar la conexi�n";
	    }
	
	
	}
}
