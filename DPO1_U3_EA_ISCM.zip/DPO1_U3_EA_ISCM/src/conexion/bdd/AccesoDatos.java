package conexion.bdd;

public interface AccesoDatos {
	
	abstract String establecerConexion ();
	abstract String insertar();
	abstract String cerrarConexion(boolean statusConexion);
	
	

}
