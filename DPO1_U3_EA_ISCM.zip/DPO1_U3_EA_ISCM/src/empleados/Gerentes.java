package empleados;

public class Gerentes extends Empleados  {

	@Override
	public
	String getDatosEmpleado() {
		
		return "El grupo de empleados es: "+ grupoEmpleado;
	}


}
