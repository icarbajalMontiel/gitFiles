package empleados;

public abstract class Empleados {
	
	protected String grupoEmpleado;
	
	@Override
    public String toString(){
    	
		return grupoEmpleado;
	}
    
    abstract String getDatosEmpleado();
    
    public void setDatos(String a){
    	
    	grupoEmpleado=a;
    }
	
}
