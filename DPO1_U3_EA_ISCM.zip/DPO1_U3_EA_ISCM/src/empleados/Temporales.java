package empleados;

public class Temporales extends Empleados{

	@Override
	public
	String getDatosEmpleado() {
		
		return "El grupo de empleados es: "+ grupoEmpleado;
	}

}
