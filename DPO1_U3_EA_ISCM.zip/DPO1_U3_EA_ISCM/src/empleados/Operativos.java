package empleados;

public class Operativos extends Empleados{

	@Override
	public
	String getDatosEmpleado() {
		return "El grupo de empleados es: "+ grupoEmpleado;
	}

}
