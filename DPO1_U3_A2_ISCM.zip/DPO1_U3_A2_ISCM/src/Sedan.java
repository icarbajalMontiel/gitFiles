//En la siguiente l�nea se hereda caracter�sticas de veh�culo 
public class Sedan extends Vehiculo {
	private Boolean descapotable;
	
	//M�todo constructor sin atributos 
	 public Sedan()
	    {
	    	
	    }
	 
	 
	public String caracteristicas(){
    return String.valueOf(descapotable);
	}
	
	//En este m�todo se usa el polimorfismo, ya que el comportamiento para mostrar los datos del vehiculo es diferente
	

	public String datosVehiculo(){
		return "Chevrolet"+" Spark"+" 2020"+" 130000.0"+" Falso";
	}
	
	
	 
}
