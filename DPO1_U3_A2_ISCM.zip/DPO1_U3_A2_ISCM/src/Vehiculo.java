
public class Vehiculo {
	private String marca;
	private String modelo;
	private int anio;
	private Double precio;
	
	 //Metodo constructor vehiculo sin atributos 
    public Vehiculo()
    {
    	
    }
    
    //En el m�todo datosVehiculo podemos oberservar la sobrecarga y el polimorfismo ya que este tiene diferentes comportamientos seg�n
    //los atributos que recibe
    public String datosVehiculo(String marca, String modelo){
    	this.marca=marca;
    	this.modelo=modelo;
    	
    	return marca +" "+ modelo;
    }
    
    public String datosVehiculo(String marca, String modelo, int anio){
    	this.marca=marca;
    	this.modelo=modelo;
    	this.anio=anio;
    	
    	return marca+" "+modelo+" "+ anio;
    }
    
    public String datosVehiculo(String marca, String modelo,int anio, Double precio){
    	this.marca=marca;
    	this.modelo=modelo;
    	this.anio=anio;
    	this.precio=precio;
    	
    	return  marca+" "+modelo+" "+ anio+" "+precio;
    	
    }


    
}
