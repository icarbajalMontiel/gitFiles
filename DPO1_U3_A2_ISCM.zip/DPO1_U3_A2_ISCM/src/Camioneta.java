//En la siguiente l�nea se hereda caracter�sticas de veh�culo 
public class Camioneta extends Vehiculo{
	
	private Double capacidadCarga;
	private String traccion;
	
	public Camioneta(){
		
	}
	
	public String caracteristicas(){
	   return String.valueOf(capacidadCarga)+traccion;
	}
	
	//En este m�todo se usa el polimorfismo, ya que el comportamiento para mostrar los datos del vehiculo es diferente
	public String datosVehiculo(){
		
		return "Ford"+" Lobo"+" 2020"+" 986700.0"+" 650"+" 500";
	}

}
