
public class tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Sedan a=new Sedan();
		Camioneta b=new Camioneta();
		Vehiculo f=new Vehiculo();
		//En la siguiente impresi�n en consola se puede distinguir el polimorfismo a pesar d eusar el mismo m�todo
		System.out.println(a.datosVehiculo());
		System.out.println(b.datosVehiculo());
		System.out.println(f.datosVehiculo("Audi", "A2", 2019, 250000.00));
		
	}

}
