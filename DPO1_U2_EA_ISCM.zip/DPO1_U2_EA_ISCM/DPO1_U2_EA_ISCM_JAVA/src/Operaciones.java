
public class Operaciones {
	
	public float getPromedio(float numeros[]){
		
		float promedio=0;
		float acumulador=0;
		
		for(int i=0;i<numeros.length;i++)
		{
			acumulador+=numeros[i];
		}
		promedio=acumulador/numeros.length;
		
		return promedio;	
	}
	
	public String getMayorMenorIgual(float a,float b){
		
		String mensaje="";
		if (a>b){
			
		 mensaje="El primer n�mero es mayor que el segundo\n";
		
		 }
		
		else if(a<b){
		 mensaje="El primer n�mero es menor que el segundo\n";
		}
		
		else{
		mensaje="Son iguales\n";
		}
		
		return mensaje;
		
		
	}
}
