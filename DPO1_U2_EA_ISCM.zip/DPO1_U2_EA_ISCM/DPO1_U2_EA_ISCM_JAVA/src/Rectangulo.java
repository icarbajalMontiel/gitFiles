
public class Rectangulo {
	
	public float area(float ancho, float largo){
		
		return ancho*largo;
	}

}
