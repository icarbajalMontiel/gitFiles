

/**Este programa ejercutar un men� y seleccionar una opci�n 
 * Calcula el �rea de un rect�ngulo, tri�ngulo, promedio y
 * Encontrar el mayor, menor o igual de dos n�meros
 * 
 *  By: Israel Carbajal Montiel
 *  
 *  
 *  **/

import java.util.*;
public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int a;
		
		do{ //Ciclo Do para iterar el men� indefinidamente, mientras sea diferente de 0
			System.out.println("");
			System.out.println("-----------MEN�--------------");
			System.out.println("");
			System.out.println("1.  Calcular el �rea de un rect�ngulo");
			System.out.println("2.  Carcular el �rea de un tri�ngulo");
			System.out.println("3.  Calcular promedio");
			System.out.println("4.  Encontrar mayor, menor o igual de dos n�meros");
			System.out.println("0.  Salir");
			//Secci�n del c�digo para recibir la opci�n desde el teclado
			System.out.println("");
			System.out.println("Introduce la operaci�n: ");
			a=s.nextInt();
			System.out.println("Opci�n seleccionada " + a);
			System.out.println("");


			switch(a)
			{
			case 0:
				System.out.println("Hasta la proxima");
			    System.out.println("      �Bye!");
				break;
			case 1:
				System.out.println("----------------------------------------");
				System.out.println("");
				System.out.println("        Calcular el �rea de un rectangulo       ");
				System.out.println("");
				System.out.println("Introduce la magnitud del ancho: ");
				float x=s.nextFloat();
				System.out.println("Introduce la magnitud del largo: ");
				float y=s.nextFloat();
				Rectangulo rec= new Rectangulo();
				System.out.println("El �rea del rect�ngulo es: " + rec.area(x, y));
				System.out.println("");
				break;
			
			
			case 2:
				System.out.println("----------------------------------------");
				System.out.println("");
				System.out.println("        Calcular el �rea de un tri�ngulo       ");
				System.out.println("");
				System.out.println("Introduce la magnitud de la base: ");
				float z=s.nextFloat();
				System.out.println("Introduce la magnitud de la altura: ");
				float v=s.nextFloat();
				Triangulo tri= new Triangulo();
				System.out.println("El �rea del rect�ngulo es: " + tri.area(z, v));  
				System.out.println("");
				break;
			
			
			case 3:
				System.out.println("----------------------------------------");
				System.out.println("");
				System.out.println("        Promedio       ");
				System.out.println("");
				System.out.println("Introduce la cantidad de n�meros a promediar: ");
				int n=s.nextInt();
				float []arreglo=new float[n];
				
				System.out.println("Inicio");
				
				for(int i=0;i<n;i++){
					System.out.print( (i+1)+"-> ");
					float w=s.nextFloat();
					arreglo[i]=w;
				}
				System.out.println("Fin");
				Operaciones oper=new Operaciones();
				System.out.println("El promedio es: " + oper.getPromedio(arreglo)); 
				System.out.println("");
				break;
				
		
			
			case 4:
				System.out.println("----------------------------------------");
				System.out.println("");
				System.out.println("Encontrar mayor, menor o igual de dos n�meros");
				System.out.println("");
				System.out.println("Introduce el primer n�mero: ");
				float n1=s.nextFloat();
				System.out.println("Introduce el segundo n�mero: ");
				float n2=s.nextFloat();
				Operaciones ope= new Operaciones();
				System.out.println(ope.getMayorMenorIgual(n1, n2));
			
			
				
			default:
				System.out.println("Opci�n invalida  ");
				break;
			}
			
			
			
		 }while(a!=0);
		
		
		
	}

}
