
public class Triangulo {
	
    public float area(float base, float altura){
		
		return (base*altura)/2;
	}


}
