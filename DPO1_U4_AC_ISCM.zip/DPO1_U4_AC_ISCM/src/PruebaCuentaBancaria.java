//Autor: Israel Carbajal Montiel

import java.util.*;
public class PruebaCuentaBancaria {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		Scanner z=new Scanner(System.in);
		Scanner x=new Scanner(System.in);
		int a;
		System.out.println("SISTEMA PILOTO BANCARIO ONLINE");
		CuentaBancaria per= new CuentaBancaria();
		
		do{
	
			
			//Men� de opciones
			System.out.println("");
			System.out.println("        OPERACI�N");
			System.out.println("");
			System.out.println("|1.|  Registro de datos");
			System.out.println("|2.|  Prueba de retiros");
			System.out.println("|3.|  Salir");
			System.out.println("");
			System.out.print("Introduce la operaci�n: \n>> ");
			a=s.nextInt();
			
			
			//Ciclo switch para el men� de prueba
			switch(a){
			
			case 1:
				System.out.println("");
				System.out.println("--------------------------------------------------");
				System.out.print("Introduce el nombre del cliente: \n>> ");
				String nombre=z.nextLine();				//Estructura evita que el nombre  tenga una longitud  vac�a 
				if (nombre.length()==0){
					System.out.println("Error,Cadena vac�a");
					break;
				}
				else{
				per.setNombre(nombre);
			    }
				
				System.out.print("Introduce el n�mero de cuenta: \n>> ");
				String nCuenta=z.nextLine();
				
				//Estructura evita que el n�mero de cuenta tenga una longitud del nv
				if (nCuenta.length()==0){
					System.out.println("Error,Cuenta no v�lida");
					break;
				}
				else{
				per.setNumero(nCuenta);
			    }
				
				//Esta estrcutura utiliza el m�todo asignarSaldoCUneta para evitar introducir saldos menores que cero
				
				System.out.print("Introduce el saldo: \n>> ");
				double saldo=x.nextDouble();
				asignarSaldoCuenta(saldo, per);
				break;
				
				
							
				
				
			//Este caso permite realizar retiros, evitando aquellos que son mayores que el saldo 
			case 2:
				System.out.println("       Datos del Usuario");
				System.out.println("--------------------------------");
				System.out.println("Nombre: "+per.getNombre());
				System.out.println("No. cuenta: "+ per.getNumero());
				
				System.out.print("Introduce el monto a retirar : \n>> ");
				double retiro=x.nextDouble();
				if (retiro>per.getSaldo()){
					System.out.println("El monto a retirar excede el saldo de la cuenta");
				}
				
				else{
				    saldo=per.getSaldo()-retiro;
				    System.out.println("Saldo actual:"+saldo);
					per.setSaldo(saldo);
					
				}
			
				break;
			 
			case 3:
				System.out.println("Hasta la proxima");
			    System.out.println("      �Bye!");
				break;
				
				
			default:
				System.out.println("Opci�n invalida  ");
				break;
			}
			
						 }while(a!=3);
		
		}
	
	//Este m�todo permite asignar un saldo que sea mayor o igual a cero, en caso contario lanza un aviso y
	//se permite realizar otro intento
	 public static void asignarSaldoCuenta(double saldo, CuentaBancaria persona){
		 Scanner s=new Scanner(System.in);
		 if(saldo<0){
				System.out.println("Error,Cantidad negativa");
				System.out.print("Introduce el saldo: \n>> ");
				saldo=s.nextDouble();
				persona.setSaldo(saldo);
			}
			else{
				persona.setSaldo(saldo);
			}
		   
	   }

	}

 