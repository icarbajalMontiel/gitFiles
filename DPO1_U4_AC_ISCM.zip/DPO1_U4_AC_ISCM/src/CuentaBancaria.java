//Clase cuenta bancaria
public class CuentaBancaria {
	//Atributos
	private String nombre;
	private String numero;
	private double saldo;
	
	//Constructor sin atributos
	public CuentaBancaria(){
		
	}
	//Constructor con atributos
	public CuentaBancaria(String nombre,String numero, double saldo){
		super();
		this.nombre=nombre;
		this.numero=numero;
		this.saldo=saldo;
	}
	
	//M�todos getters 
	public String getNombre(){
		return nombre;
	}
	
	public String getNumero(){
		return numero;
	}
	
	public double getSaldo(){
		return saldo;
	}
	
	//M�todos setters
	public void setNombre(String nombre){
		this.nombre=nombre;
	}
	
	public void setNumero(String numero){
		this.numero=numero;
	}
	public void setSaldo(double saldo){
		this.saldo=saldo;
	}
	
	
	
	
}
