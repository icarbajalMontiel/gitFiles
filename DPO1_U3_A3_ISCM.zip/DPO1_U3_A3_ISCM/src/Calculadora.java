import java.util.*;
public class Calculadora {
	public static Integer factorial=null;
	
		public static void main(String[] args)  {
		// TODO Auto-generated method stub
		int a=0;
		int b=0;
		Scanner s = new Scanner(System.in);
	
	     try{
	    	 System.out.println("Introduce el primer n�mero: ");
			 a= s.nextInt(); 
			 System.out.println("Introduce el segundo n�mero: ");
			 b = s.nextInt();
			 System.out.println("");
	     }
	     
	     catch(InputMismatchException ex){
	    	 System.out.println("Error: "+ ex.getMessage());
	    	 a=0;
	    	 b=0;
	    	factorial=0;
	     }
	     
	     finally{
	    	 OperacionesMatematicas oper= new OperacionesMatematicas ();
			 System.out.println("La suma es: " + oper.getSuma(a, b));
			 System.out.println("La resta es: " + oper.getResta(a, b));
			 System.out.println("La multiplicaci�n: " + oper.getMultiplicacion(a, b));
			 System.out.println("La divisi�n: " + oper.getDivision(a, b));
			 System.out.println("El m�dulo: " + oper.getModulo(a, b));
	     }
	     System.out.println("-------------------------------------------");
	     OperacionesMatematicas oper= new OperacionesMatematicas ();
	     System.out.println("Esta parte calcula el factorial de un n�mero:");
		 try{
			oper.getFactorial(factorial);
		 }
		
		 catch(NullPointerException ex){
			factorial=s.nextInt();
		 }
		
		 finally{
			 
			 System.out.println("El factorial es: " + oper.getFactorial(factorial));
			 
		 }     
	}

}
