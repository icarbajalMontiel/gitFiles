
public class OperacionesMatematicas {

	public int getSuma(int a,  int b){ //Aqu� se pasan los argumentos del m�todo 
		
		int c=a+b;
		 return c;                           //Aqu� se retorna el valor de c
		
	}
	
    public int getResta(int a, int b){ //Aqu� se pasan los argumentos del m�todo 
		
		int c=a-b;
		 return c;                           //Aqu� se retorna el valor de c
		
	}
	
    public int getMultiplicacion(int a, int b){ //Aqu� se pasan los argumentos del m�todo 
		
		int c=a*b;
		return c;                                     //Aqu� se retorna el valor de c
	}
	
    public int getDivision(int a, int b){ //Aqu� se pasan los argumentos del m�todo 
           int c=0;
		try{
		    c=a/b;
		}catch(ArithmeticException ex){
			c= 0;
		}
		finally{
			return c;
		}                                 //Aqu� se retorna el valor de c
	}
	
    
    public int getModulo(int a, int b){ //Aqu� se pasan los argumentos del m�todo 
    	   int c=0;
   		try{
   		    c=a%b;
   		}catch(ArithmeticException ex){
   			c= 0;
   		}
   		finally{
   			return c;
   		}   
	}
    
   public int getFactorial(int a){
	   int acumu=1;
		   for(int i=1;i<=a;i++){
			   
			   acumu=i*acumu;
		   }
		   return acumu;
       }
    
  }
