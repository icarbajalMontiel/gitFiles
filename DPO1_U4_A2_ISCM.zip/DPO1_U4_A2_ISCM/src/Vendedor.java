//Clase vendedor
public class Vendedor {
	
	private String nombre;
	
	//Constructor con atributo
	public Vendedor(String nombre){
		super();
		this.nombre=nombre;
	
	}
	//Constructor sin atributo
	public Vendedor(){
		
	}
	//Getters y setters
	public void setNombre (String nombre){
		this.nombre=nombre;
	}
	
	public String getNombre(){
		return nombre;
	}
	

} 
