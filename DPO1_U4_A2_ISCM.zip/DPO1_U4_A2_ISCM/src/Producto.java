//Clase producto
public class Producto {

	private int cantidad;
	//M�todo constructor con atributos
	public Producto(int cantidad){
		super();
		this.cantidad=cantidad;
	}
	//M�todo constructor sin atributos
	public Producto()
	{
		
	}
	//Getters y setters
	public void setCantidad(int cantidad){
		this.cantidad=cantidad;
	}
	
	public int getCantida(){
		return cantidad;
	}
	

	
	

}
