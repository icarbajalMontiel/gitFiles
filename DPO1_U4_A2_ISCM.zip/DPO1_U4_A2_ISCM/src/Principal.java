//Autor:Israel Carbajal Montiel 
//Programa: Para capturar la carga de producto Bon Ice

import java.util.*;
public class Principal {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Declaraci�n de variable y objetos
		int n=0;
		Vendedor [] ven=new Vendedor[50];
		Producto [][] pro=new Producto[50][4];
		Scanner s=new Scanner(System.in);
		Scanner z=new  Scanner(System.in);
		System.out.println("-------------------------------------------------");
		System.out.println("        Bonne Ice Registro de Cargas Versi�n 2.0");
		System.out.println("--------------------------------------------------");
		
		//Categorias del tipo de producto
		String tipoProducto []={"Sencillo", "Doble","BonIsote","Mega"};
		int a;
		do{
			//Men� de opciones
			System.out.println("");
			System.out.println("       MEN� DE OPERACIONES");
			System.out.println("");
			System.out.println("|1.|  Capturar las cargas de los vendedores");
			System.out.println("|2.|  Mostrar las cargas de todos los vendedores");
			System.out.println("|3.|  Obtener totales de carga por categoria de producto");
			System.out.println("|4.|  Salir");
			System.out.println("");
			System.out.print("Introduce la operaci�n: \n>>");
			a=s.nextInt();
			
			if (a==1){
				System.out.println("");
				System.out.println("Teclea el n�mero de vendedores a cargar");
				n=s.nextInt();
				//Este ciclo permite guardar el nombre en un arreglo 
				for(int i=0;i<n;i++){
					ven[i]=new Vendedor();
					System.out.println("----------------------------------------");
					System.out.println("Escribe el nombre del vendedor");
					String b=z.nextLine();
					ven[i].setNombre(b);
					System.out.println("----------------------------------------");
				//Este ciclo permite guardar los datos en un matriz nx4
					for(int j=0;j<4;j++){
						pro[i][j]=new Producto();
						System.out.print("Cantidad de "+ tipoProducto[j]+ ":");
						int canti=s.nextInt();
						pro[i][j].setCantidad(canti);
					}
					
				}
		
			}
			//Esta opci�n permite mostrar toda la informaci�n capturada en un tabla
			else if(a==2){
				System.out.println("-----------------------------------------------");
				System.out.println("| Nombre | Sencillo | Doble | BonIsote | Mega |");
				System.out.println("-----------------------------------------------");
				for (int i=0;i<n;i++){
					System.out.println();
					System.out.print(" "+ven[i].getNombre()+" ");
					for (int j=0;j<4;j++){
						System.out.print("     "+pro[i][j].getCantida()+"    ");
				}
				System.out.println("\n-----------------------------------------------");
			}
				
		}
		//Esta opci�n muestra el total de cada categoria del producto
			else if(a==3){
					int suma=0;
				System.out.println("");
				System.out.println("| Nombre | Sencillo | Doble | BonIsote | Mega |");
				System.out.println("-----------------------------------------------");
				System.out.print("  Total ");
				for (int j=0;j<4;j++){
					for (int i=0;i<n;i++){
						suma=suma+pro[i][j].getCantida();
				}
					System.out.print("     "+suma+"    ");
					suma=0;
			  }
				System.out.println("\n-----------------------------------------------");
				System.out.println("");
			}
		
			
			//Esta condici�n evita que al seleccionar salir se imprima el caso else "opci�n invalida"
			else if(a==4){
				continue;
			}
			// Est� condici�n se ejecuta al presionar alguna opci�n no contemplada en el men� 
			else{
				System.out.println("");
				System.out.println("Opci�n invalida  ");
			}
			
		
		}while(a!=4);
		
		System.out.println("\nChao, Bye");

	}

}
