//Clase Autom�vil 
public class Automovil {
	
	//Declaraci�n de atributos
	private String marca;
	private String modelo;
	private float valorComercial;
	private char tipoAutomovil;
	private float valorFinal;
	
	//Constructor con todos los atributos
	public Automovil (String marca,String modelo, float valorComercial, char tipoAutomovil, float valorFinal){
		super ();
		this.marca=marca;
		this.modelo=modelo;
		this.valorComercial=valorComercial;
		this.tipoAutomovil=tipoAutomovil;
		this.valorFinal=valorFinal;
	}
	//Constructor sin atributos 
	public Automovil(){
		
	}
	
	//M�todos getters y setters de los atributos
	public void  setMarca(String marca){
		this.marca=marca;
	}
	public void  setModelo(String modelo){
		this.modelo=modelo;
	}
	public void  setValorComercial(float valorComercial){
		this.valorComercial=valorComercial;
	}
	public void  setTipoAutomovil(char tipoAutomovil){
		this.tipoAutomovil=tipoAutomovil;
	}
	public void  setvalorFinal(float valorFinal){
		this.valorFinal=valorFinal;
	}
	
	public String getMarca(){
		return marca;
	}
	public String getModelo(){
		return modelo;
	}
	public float getValorComercial(){
		return valorComercial;
	}
	public char tipoAutomovil(){
		return tipoAutomovil;
	}
	public float getValorFinal(){
		return valorFinal;
	}
	
	//M�todo para calcular el valor final
	public float getValorFinal(float cantidad){
		float acum=0;
		if (cantidad<150000){
			acum=(float) ((0.16)*(cantidad));
			cantidad=cantidad+acum;
			return cantidad;
		}
		else 
		{
			acum=(float)((0.20)*(cantidad));
			cantidad=cantidad+acum;
			return cantidad;
		}
	}
	
	
	
	
}