import java.util.*;
public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s= new Scanner(System.in);
		Scanner a= new Scanner(System.in);
		System.out.println("Escribe el n�mero de registros a almacenar");
		int n=s.nextInt();
		Automovil arreglo[]=new Automovil[n]; //Se crea un arreglo  de Automoviles de tama�o n
		for (int i=0;i<n;i++){
			System.out.print( (i+1)+"-> ");
		    arreglo[i]=new Automovil(); //Se instancia un  Automovil en el arreglo de i;
		    //Se a�aden los datos correpondientes del Automovil i
			System.out.println("Inserta la marca del automovil:");
			String m=a.nextLine();
			arreglo[i].setMarca(m); 
			System.out.println("Inserta el modelo del automovil:");
			String z=a.nextLine();
			arreglo[i].setModelo(z);
			System.out.println("Inserta el valor comercial:");
			float v=s.nextFloat();
			arreglo[i].setValorComercial(v);
			System.out.println("Inserte el tipo del auto F-Familiar, P-P�blico o C-Carga:");
			char t=s.next().charAt(0);
			arreglo[i].setTipoAutomovil(t);
			arreglo[i].setvalorFinal(arreglo[i].getValorFinal(v));
			System.out.println("-----------------------------------------------------------");
		}
		
		//Se imprimen los datos almacenados en el arreglo
		System.out.println("              Datos almacenados  ");
		System.out.println("");
		System.out.println("|No.|  Marca    |  Modelo  | Valor Com. | Tipo | Valor Final |");
		System.out.println("-----------------------------------------------------------");
		
		//Se recorre cada uno de los elementos del arreglo y se imprimen cada uno de sus atributos
		for(int i=0;i<n;i++){
			
			System.out.println("| "+(i+1)+" |  "+arreglo[i].getMarca()+",    "+arreglo[i].getModelo()+",    "+
		arreglo[i].getValorComercial()+",     "+arreglo[i].tipoAutomovil()+",    "+arreglo[i].getValorFinal());
			System.out.println("-----------------------------------------------------------");
		}
	}

}
