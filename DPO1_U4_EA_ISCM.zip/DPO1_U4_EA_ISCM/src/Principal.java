
//Autor:Israel Carbajal Montiel 
//Programa: Sistema Escolar
//Descrpci�n: Permite calcular el promedio de califcaciones seg�n el n�mero de materias y alumnos 

import java.util.*;
public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Declaraci�n de varibles y objetos 
		int n=0;
		int alum=0;
		Asignatura [] materia=new Asignatura[10];
		Asignatura [][] califi=new Asignatura [10][10];
		Scanner s=new Scanner (System.in);
		Scanner z=new Scanner (System.in);
		System.out.println("-------------------------------------------------");
		System.out.println("        Sistemas Escolares Versi�n 1.0");
		System.out.println("--------------------------------------------------");
		int a;
		
		do{
			//Men� de opciones
			System.out.println("");
			System.out.println("       MEN� DE OPERACIONES");
			System.out.println("");
			System.out.println("|1.|  Registrar asignatura");
			System.out.println("|2.|  Guardar calificaciones");
			System.out.println("|3.|  Mostrar estad�stica");
			System.out.println("|4.|  Salir");
			System.out.println("");
			System.out.print("Introduce la operaci�n: \n>> ");
			a=s.nextInt();
			//Esta opci�n se utiliza para guardar en un arreglo unidimensionales el nombre de las asignaturas y clave
			if(a==1){
				System.out.println("");
				System.out.println("--------------------------------------------------");
				System.out.print("Introduce el n�mero de asignaturas a registrar: \n>> ");
				n=s.nextInt();
				//Se recorre el arreglo para insertar uno a uno los datos
				for(int i=0;i<n;i++){
					materia[i]=new Asignatura();
					System.out.println("----------------------------------------");
					System.out.print("Escribe el nombre de la asignatura: \n>> ");
					String b=z.nextLine();
					materia[i].setNombre(b);
					System.out.print("Escribe la clave: \n>> ");
					b=z.nextLine();
					materia[i].setClave(b);
				}
			}
			//Esta opci�n permite introducir la calificaci�n de cada materia seg�n el n�mero de los alumnos
			else if(a==2){
				System.out.println("");
				System.out.println("----------------------------------------------");
				System.out.print("Introduce el n�mero de alumnos: \n>> ");
				alum=s.nextInt();
				System.out.println("---------------------------------------------");
			//Se recorre la matriz, donde las filas son las asignaturas y las columnas el n�mero de alumnos
				for(int i=0;i<n;i++){
					System.out.println("      "+materia[i].getNombre());
					System.out.println("---------------------------------------------");
					for (int j=0;j<alum;j++){
						califi[i][j]=new Asignatura();
						System.out.print("|"+"No. "+(j+1)+"|"+"Calificaci�n: \n>> ");
						int cali=s.nextInt();
						califi[i][j].setCalificacion(cali);
						
					}
					System.out.println("--------------------------------------------------");
					
				}

			}
			//Esta opci�n permite realizar estad�stica con los calificaciones de cada materia
			//Para esto se utiliza una clase operaciones que cuenta con los m�todos de promedio, mayor y menor.
			else if(a==3){
				Operaciones op= new Operaciones();
				float [] arreglo=op.getPromedio(califi, n, alum);
				int [] arreglo1=op.getMayor(califi, n, alum);
				int [] arreglo2=op.getMenor(califi, n, alum);
				System.out.println("-----------------------------------");
				for(int i=0;i<n;i++){
				System.out.println(" "+materia[i].getNombre() );
				System.out.println("-----------------------------------");
				System.out.println("Promedio: "+arreglo[i] );
				System.out.println("   Mayor: "+arreglo1[i] );
				System.out.println("   Menor: "+arreglo2[i] );
				System.out.println("------------------------------------");
				
				}
			}
			
			//Esta condici�n evita que al seleccionar salir se imprima el caso else "opci�n invalida"
	        else if(a==4){
				continue;
				}
				// Est� condici�n se ejecuta al presionar alguna opci�n no contemplada en el men� 
			else{
				System.out.println("");
				System.out.println("Opci�n invalida  ");
				}
				
				
			
			
		}while(a!=4);
		
		

	}

}
