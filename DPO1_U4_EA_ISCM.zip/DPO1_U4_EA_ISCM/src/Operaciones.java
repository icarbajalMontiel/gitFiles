
public class Operaciones {
	
	//M�todo para calcular el promedio por fila de una matriz nxm
	public float [] getPromedio(Asignatura arreglo [][],int fila, int columna){
		
		float acumulador=0;
		float [] promedioFila =new float[fila];
		for (int i=0; i<fila; i++)
		{
			for(int j=0;j<columna;j++){
				
			acumulador+=arreglo[i][j].getCalificacion();
			
			}
			promedioFila[i]=acumulador/columna;
			acumulador=0;
		}
		
		return promedioFila;
	
	}
	
	//M�todo para encontrar la calificaci�n m�s grande de una fila en una matriz de calificaciones
	 public int [] getMayor (Asignatura arreglo [][],int fila, int columna )
	  {
		 
		 
		  int [] mayores= new int[fila];
		  //Encuetran al mayor
		  for (int i=0; i<fila; i++)
		  {
		    int mayor=arreglo[i][0].getCalificacion();
			for(int j=0;j<columna;j++){
				
				  if(arreglo[i][j].getCalificacion() > mayor)
				    {
				    	mayor=arreglo[i][j].getCalificacion();
				    
				    }	  
			}
			mayores[i]=mayor;
			
		    
		  }
		  return mayores;
	  }
	
		//M�todo para encontrar la calificaci�n m�s peque�a de una fila en una matriz de calificaciones
	 public int [] getMenor (Asignatura arreglo [][],int fila, int columna )
	  {
		 
		 
		  int [] menores= new int[fila];
		  //Encuetran al menor
		  for (int i=0; i<fila; i++)
		  {
			  int menor=arreglo[i][0].getCalificacion();
			for(int j=0;j<columna;j++){
				
				  if(arreglo[i][j].getCalificacion()<menor)
				    {
				    	menor=arreglo[i][j].getCalificacion();
				    
				    }	  
			}
			menores[i]=menor;
			
		  }
		  return menores;
	  }
	
	
	
	
	
	
	

}
