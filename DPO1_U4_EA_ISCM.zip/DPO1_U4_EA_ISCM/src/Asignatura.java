//Clase asignatura
public class Asignatura {
	//atributos
	private String nombre;
	private String clave;
	private int calificacion;
	
	//Constructor
	public Asignatura(){
		
	}
	//Constructor de nombre y clave
	public Asignatura(String nombre, String clave){
		super();
		this.nombre=nombre;
		this.clave=clave;
	//Constructor con calificacion 	
	}
	public Asignatura (int calificacion){
		super();
		this.calificacion=calificacion;
	}
	
	//M�todos getters
	
	public String getNombre(){
		return nombre;
	}
	
	public String getClave(){
		return clave;
	}
	
	public int getCalificacion(){
		return calificacion;
	}
	
	//M�todos setters
	public void setNombre(String nombre){
		this.nombre=nombre;
	}
	
	public void setClave(String clave){
		this.clave=clave;
	}
	
	public void setCalificacion(int calificacion){
		this.calificacion=calificacion;
	}
	

}
