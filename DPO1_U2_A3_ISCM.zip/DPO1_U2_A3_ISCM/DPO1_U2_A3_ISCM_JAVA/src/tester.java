
/**Este programa permite conocer el �rea de tres figura geom�tricas
 * 
 *  By: Israel Carbajal Montiel
 *  
 *  
 *  **/
import java.util.*;
public class tester { //Clase para realizar una prueba del programa

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int a;
		
		do{ //Ciclo Do para iterar el men� indefinidamente, mientras no sea igual a 4
			System.out.println("");
			System.out.println("       MEN� DE OPERACIONES");
			System.out.println("");
			System.out.println("Calcular el �rea de figuras geom�tricas:");
			System.out.println("1.  Trapecio");
			System.out.println("2.  Circulo");
			System.out.println("3.  Pent�gono");
			System.out.println("4.  Salir");
			//Secci�n del c�digo para recibir la opci�n desde el teclado
			System.out.println("");
			System.out.println("Introduce la operaci�n: ");
			a=s.nextInt();
			System.out.println("Opci�n seleccionada " + a);
			System.out.println("");
			
			//Opci�n para calcular el �rea de un trapecio
			if (a==1){
				System.out.println("----------------------------------------");
				System.out.println("");
				System.out.println("                Trapecio                ");
				System.out.println("");
				System.out.println("Introduce la magnitud de la base mayor: ");
				float x=s.nextFloat();
				System.out.println("Introduce la magnitud de la base menor: ");
				float y=s.nextFloat();
				System.out.println("Introduce la magnitud de la altura: ");
				float z=s.nextFloat();
				Trapecio trap= new Trapecio(); //Se crea un objeto de tipo trapecio
				System.out.println("El �rea del trapecio es: " + trap.area(x, y, z)); //Se accede al m�todo �rea 
				System.out.println("");
			}
			
			//Opci�n para calcular el �rea de un circulo
			else if (a==2){
				System.out.println("----------------------------------------");
				System.out.println("");
				System.out.println("                Circulo                ");
				System.out.println("");
				System.out.println("Introduce el radio del circulo: ");
				float x=s.nextFloat();
				Circulo cir= new Circulo();//Se crea un objeto de tipo circulo
				System.out.println("El �rea del circulo es: " + cir.area(x));//Se accede al m�todo �rea 
				System.out.println("");
			}
			//Opci�n para calcular el �rea de un pent�gono
			else if (a==3){
				System.out.println("----------------------------------------");
				System.out.println("");
				System.out.println("                Pent�gono                ");
				System.out.println("");
				System.out.println("Introduce la magnitud del perimetro: ");
				float x=s.nextFloat();
				System.out.println("Introduce la magnitud del apotema: ");
				float y=s.nextFloat();
				Pentagono pen= new Pentagono();//Se crea un objeto de tipo pent�gono
				System.out.println("El �rea del pent�gono es: " + pen.area(x, y));//Se accede al m�todo �rea 
				System.out.println("");
			}
			//Esta condici�n evita que al seleccionar salir se imprima el caso else "opci�n invalida"
			else if(a==4){
				continue;
			}
			// Est� condici�n se ejecuta al presionar alguna opci�n no contemplada en el men� 
			else{
				System.out.println("Opci�n invalida  ");
			}
			
        }while(a!=4);
		System.out.println(" ��Bye!! ");
		
		
	}

}
