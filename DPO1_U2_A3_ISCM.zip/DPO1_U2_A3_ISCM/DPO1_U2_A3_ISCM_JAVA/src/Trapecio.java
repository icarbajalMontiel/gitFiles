
public class Trapecio {
	
	public float area(float BaseMayor, float BaseMenor, float altura){
		
		return (BaseMayor+BaseMenor)*altura;
	}
}
