
public class Circulo {
	public static float PI=3.1416f;
	
	public float area(float radio){
		
		return PI*radio*radio;
	}
}
