
public class Pentagono {
	
	public float area(float Perimetro, float Apotema){
		
		return (Perimetro*Apotema)/2;
	}

}
